[Matthew Rocklin](http://matthewrocklin.com)

[Michael Broxton](http://graphics.stanford.edu/~broxton/)
